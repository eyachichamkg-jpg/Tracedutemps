// nav.js — injects the shared nav + cart drawer into any page
// Usage: <script src="../nav.js"></script> then call TDT_NAV.init(activePage)

const TDT_NAV = (() => {

  function init(activePage = '') {
    injectStyles();
    injectHTML(activePage);
    initCartDrawer();
    TDT.initCartBadge();
  }

  function injectStyles() {
    const s = document.createElement('style');
    s.textContent = `
      /* ── Nav ── */
      #tdt-nav {
        position: fixed; top: 0; width: 100%; z-index: 50;
        background: rgba(255,248,245,0.92); backdrop-filter: blur(12px);
        border-bottom: 1px solid rgba(216,194,188,0.4);
        box-shadow: 0 1px 12px rgba(136,75,58,0.06);
        transition: all .3s ease;
      }
      #tdt-nav .inner {
        display: flex; justify-content: space-between; align-items: center;
        height: 80px; padding: 0 48px; max-width: 1600px; margin: 0 auto;
      }
      #tdt-nav .logo {
        font-family: 'Noto Serif', serif; font-style: italic; font-size: 26px;
        color: #28180b; text-decoration: none; transition: opacity .3s;
      }
      #tdt-nav .logo:hover { opacity: .75; }
      #tdt-nav .links {
        display: flex; gap: 40px; align-items: center;
        font-family: Inter, sans-serif; font-size: 11px;
        letter-spacing: .15em; text-transform: uppercase;
      }
      #tdt-nav .links a {
        color: #53433f; text-decoration: none; padding-bottom: 3px;
        transition: color .25s; border-bottom: 1px solid transparent;
      }
      #tdt-nav .links a:hover { color: #884b3a; }
      #tdt-nav .links a.active { color: #884b3a; border-bottom-color: #884b3a; }
      #tdt-nav .actions { display: flex; align-items: center; gap: 20px; }
      #tdt-nav .cart-btn {
        position: relative; background: none; border: none; cursor: pointer;
        padding: 4px; transition: opacity .25s;
      }
      #tdt-nav .cart-btn:hover { opacity: .7; }
      #tdt-nav .cart-btn .badge {
        position: absolute; top: -6px; right: -6px;
        background: #884b3a; color: #fff; font-size: 10px;
        width: 18px; height: 18px; border-radius: 50%;
        display: flex; align-items: center; justify-content: center;
        font-family: Inter, sans-serif; font-weight: 700;
      }
      /* ── Announcement Bar ── */
      #tdt-announcement {
        background: #884b3a; color: #fff;
        font-family: Inter, sans-serif; font-size: 12px;
        letter-spacing: .12em; text-align: center; padding: 10px;
        text-transform: uppercase;
      }
      /* ── Cart Drawer ── */
      #tdt-cart-overlay {
        position: fixed; inset: 0; background: rgba(40,24,11,.45);
        backdrop-filter: blur(4px); z-index: 60;
        opacity: 0; pointer-events: none;
        transition: opacity .3s;
      }
      #tdt-cart-overlay.open { opacity: 1; pointer-events: auto; }
      #tdt-cart-drawer {
        position: fixed; top: 0; right: 0; height: 100%;
        width: 100%; max-width: 420px; z-index: 70;
        background: #fff1e9;
        border-left: 1px solid #d8c2bc;
        box-shadow: -8px 0 40px rgba(40,24,11,.12);
        display: flex; flex-direction: column;
        transform: translateX(100%); transition: transform .4s cubic-bezier(.16,1,.3,1);
        padding: 32px;
      }
      #tdt-cart-drawer.open { transform: translateX(0); }
      .cart-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 32px; }
      .cart-header h2 { font-family: 'Noto Serif', serif; font-size: 24px; color: #28180b; }
      .cart-close { background: none; border: none; cursor: pointer; font-size: 22px; color: #53433f; transition: color .2s; }
      .cart-close:hover { color: #884b3a; }
      .cart-items { flex: 1; overflow-y: auto; display: flex; flex-direction: column; gap: 20px; padding-right: 8px; }
      .cart-item { display: flex; gap: 16px; align-items: flex-start; padding-bottom: 20px; border-bottom: 1px solid #d8c2bc; }
      .cart-item img { width: 80px; height: 100px; object-fit: cover; }
      .cart-item-info { flex: 1; }
      .cart-item-name { font-family: 'Noto Serif', serif; font-size: 16px; color: #28180b; }
      .cart-item-msg { font-size: 12px; color: #85736e; font-style: italic; margin-top: 4px; }
      .cart-item-price { color: #884b3a; font-weight: 700; font-size: 15px; margin-top: 8px; font-family: Inter, sans-serif; }
      .cart-item-qty { display: flex; align-items: center; gap: 12px; margin-top: 8px; }
      .qty-btn { background: none; border: 1px solid #d8c2bc; width: 28px; height: 28px; cursor: pointer; color: #53433f; font-size: 14px; transition: all .2s; }
      .qty-btn:hover { background: #884b3a; color: #fff; border-color: #884b3a; }
      .qty-val { font-family: Inter, sans-serif; font-size: 14px; min-width: 20px; text-align: center; }
      .cart-remove { background: none; border: none; cursor: pointer; color: #85736e; font-size: 18px; margin-left: auto; transition: color .2s; }
      .cart-remove:hover { color: #ba1a1a; }
      .cart-footer { padding-top: 24px; border-top: 1px solid #d8c2bc; margin-top: auto; }
      .cart-total-row { display: flex; justify-content: space-between; margin-bottom: 20px; }
      .cart-total-label { font-family: Inter, sans-serif; font-size: 14px; color: #53433f; }
      .cart-total-val { font-family: 'Noto Serif', serif; font-size: 22px; font-weight: 700; color: #28180b; }
      .cart-checkout-btn {
        width: 100%; background: #884b3a; color: #fff;
        border: none; padding: 18px; cursor: pointer;
        font-family: Inter, sans-serif; font-size: 11px;
        letter-spacing: .2em; text-transform: uppercase;
        transition: filter .2s;
      }
      .cart-checkout-btn:hover { filter: brightness(1.15); }
      .cart-empty { text-align: center; padding: 60px 20px; color: #85736e; }
      .cart-empty p { font-family: 'Noto Serif', serif; font-style: italic; font-size: 18px; margin-bottom: 20px; }
      .cart-empty a { color: #884b3a; text-decoration: none; font-size: 13px; letter-spacing: .12em; text-transform: uppercase; border-bottom: 1px solid #884b3a; padding-bottom: 2px; }
      @media(max-width:768px) {
        #tdt-nav .links { display: none; }
        #tdt-nav .inner { padding: 0 20px; }
        #tdt-cart-drawer { max-width: 100%; }
      }
    `;
    document.head.appendChild(s);
  }

  function injectHTML(activePage) {
    const s = TDT.getSettings();
    // Announcement bar
    if (s.bannerVisible !== false) {
      const ann = document.createElement('div');
      ann.id = 'tdt-announcement';
      ann.textContent = s.announcementBar;
      ann.style.background = s.bannerBg || '#884b3a';
      ann.style.color = s.bannerColor || '#fff';
      document.body.prepend(ann);
    }

    // Nav
    const nav = document.createElement('nav');
    nav.id = 'tdt-nav';
    const pages = [
      { key: 'collections', label: s.nav1label || 'Collections', href: '../collections/index.html' },
      { key: 'story',       label: s.nav2label || 'Our Story',   href: '../homepage/index.html#story' },
      { key: 'gifts',       label: s.nav3label || 'Gifts',       href: '../collections/index.html#gifts' },
      { key: 'bespoke',     label: s.nav4label || 'Bespoke',     href: '../bespoke/index.html' },
    ];
    nav.innerHTML = `
      <div class="inner">
        <a class="logo" href="../homepage/index.html">${s.brandName || 'TraceDuTemps'}</a>
        <div class="links">
          ${pages.map(p => `<a href="${p.href}" class="${activePage===p.key?'active':''}">${p.label}</a>`).join('')}
        </div>
        <div class="actions">
          <button class="cart-btn" id="tdt-cart-open" aria-label="Panier">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#884b3a" stroke-width="1.5"><path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 01-8 0"/></svg>
            <span class="badge" data-cart-badge style="display:none">0</span>
          </button>
          <a href="../admin/index.html" title="" style="opacity:0;width:12px;height:32px;display:inline-block;pointer-events:auto;" aria-hidden="true"></a>
        </div>
      </div>`;
    const annEl = document.getElementById('tdt-announcement');
    document.body.insertBefore(nav, annEl ? annEl.nextSibling : document.body.firstChild);

    // Cart overlay
    const overlay = document.createElement('div');
    overlay.id = 'tdt-cart-overlay';
    overlay.addEventListener('click', closeCart);
    document.body.appendChild(overlay);

    // Cart drawer
    const drawer = document.createElement('div');
    drawer.id = 'tdt-cart-drawer';
    drawer.innerHTML = `
      <div class="cart-header">
        <h2>Votre Panier</h2>
        <button class="cart-close" id="tdt-cart-close">✕</button>
      </div>
      <div class="cart-items" id="tdt-cart-items"></div>
      <div class="cart-footer" id="tdt-cart-footer"></div>`;
    document.body.appendChild(drawer);

    // Adjust body padding for banner + nav
    const bannerH = s.bannerVisible !== false ? 36 : 0;
    document.body.style.paddingTop = (bannerH + 80) + 'px';

    // Apply custom colors if set
    if (s.colorPrimary && s.colorPrimary !== '#884b3a') {
      document.documentElement.style.setProperty('--primary-override', s.colorPrimary);
    }
  }

  function initCartDrawer() {
    document.getElementById('tdt-cart-open').addEventListener('click', openCart);
    document.getElementById('tdt-cart-close').addEventListener('click', closeCart);
    window.addEventListener('tdt:cartUpdated', renderCart);
    renderCart();
  }

  function openCart() {
    document.getElementById('tdt-cart-overlay').classList.add('open');
    document.getElementById('tdt-cart-drawer').classList.add('open');
    document.body.style.overflow = 'hidden';
    renderCart();
  }

  function closeCart() {
    document.getElementById('tdt-cart-overlay').classList.remove('open');
    document.getElementById('tdt-cart-drawer').classList.remove('open');
    document.body.style.overflow = '';
  }

  function renderCart() {
    const cart = TDT.getCart();
    const itemsEl = document.getElementById('tdt-cart-items');
    const footerEl = document.getElementById('tdt-cart-footer');
    if (!itemsEl) return;

    if (cart.length === 0) {
      itemsEl.innerHTML = `<div class="cart-empty"><p>Votre panier est vide.</p><a href="../collections/index.html">Explorer la collection →</a></div>`;
      footerEl.innerHTML = '';
      return;
    }

    itemsEl.innerHTML = cart.map(item => `
      <div class="cart-item">
        <img src="${item.img}" alt="${item.name}">
        <div class="cart-item-info">
          <div class="cart-item-name">${item.name}</div>
          ${item.message ? `<div class="cart-item-msg">"${item.message}"</div>` : ''}
          <div class="cart-item-price">${(item.price * item.qty).toFixed(0)} TND</div>
          <div class="cart-item-qty">
            <button class="qty-btn" onclick="TDT.updateQty(${item.id},'${item.message.replace(/'/g,"\\'")}', -1)">−</button>
            <span class="qty-val">${item.qty}</span>
            <button class="qty-btn" onclick="TDT.updateQty(${item.id},'${item.message.replace(/'/g,"\\'")}', 1)">+</button>
          </div>
        </div>
        <button class="cart-remove" onclick="TDT.removeFromCart(${item.id},'${item.message.replace(/'/g,"\\'")}')">✕</button>
      </div>`).join('');

    const total = TDT.getCartTotal();
    const settings = TDT.getSettings();
    const shipping = total >= settings.shippingFreeAbove ? 0 : settings.shippingFee;
    footerEl.innerHTML = `
      <div class="cart-total-row">
        <span class="cart-total-label">Sous-total</span>
        <span class="cart-total-val">${total.toFixed(0)} TND</span>
      </div>
      ${shipping > 0 ? `<div class="cart-total-row" style="opacity:.65"><span class="cart-total-label" style="font-size:12px">Livraison</span><span style="font-family:Inter;font-size:13px">${shipping} TND</span></div>` : `<div style="font-family:Inter;font-size:12px;color:#884b3a;margin-bottom:12px;text-align:center">✓ Livraison gratuite</div>`}
      <button class="cart-checkout-btn" onclick="window.location.href='../checkout/index.html'">Finaliser la commande</button>
      <p style="text-align:center;font-size:11px;font-family:'Noto Serif',serif;font-style:italic;color:#85736e;margin-top:12px">${settings.cartDeliveryNote || 'Livraison assurée dans 48h sur Grand Tunis'}</p>`;
  }

  return { init, openCart, closeCart, renderCart };
})();
