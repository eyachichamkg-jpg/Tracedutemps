// TraceDuTemps — Shared Store (cart + products)
// All pages import this via <script src="../store.js">

const TDT = (() => {
  // ── Products (admin-editable via localStorage) ──────────────────────────
  const DEFAULT_PRODUCTS = [
    { id: 1,  name: "Message Table",     price: 35,  badge: "MUST HAVE", img: "https://lh3.googleusercontent.com/aida/ADBb0uhKQztGayDXjj4JStImkSM6HNWbWRtmPyFtBD6hnuFBqFFydjeUVvv07oFr5XmvkFILK2bo_RKiWauW5hpEW6A5bx0AnZcZbOfQ-FDXjeboIZk17fNdjhzEHvFbPx4Zmxuj2xbZei5x7bO8KI5XjeBlXuZFIs0xTCgJTENtMDOFu0SW8fzk192-0KkkqJYyF9OMRv-UEjjSxUCrxNpN6CywS7YIpSydXzM2luNRKdSoOCd5aoUCTvnapP5OhX189JsigSEKkzkbszI", placeholder: "\"Pour les matins doux\"", category: "table" },
    { id: 2,  name: "Plateau Œufs",      price: 45,  badge: "",           img: "https://lh3.googleusercontent.com/aida/ADBb0uioG2E1QqcimzR-PSX5zT5bZn3oP-QVIrSd_d_knnX31svgypcPFWyJ84SbNelJolrSGi4vUw4idol68zpEx3UrXlSRShsi60SG7d8xl6VcD85nK7K3SxIhc9aefs5rTI0Q_swbUgK5OSoQhYu2Nqn3co3XN2dJ1NYiy5ZsF-oTqvKBUCoc778zMUSTHqsGVeYCjEXq5e6ItaEZUBHIZo7f1akdqT8yrJri9pSSp2onwNwxBUxyHQ2838_dezo9MioU9z6xg75YCQ", placeholder: "Cœur Pattern", category: "deco" },
    { id: 3,  name: "Vase Éclosion",     price: 85,  badge: "",           img: "https://lh3.googleusercontent.com/aida/ADBb0uhrCnQiZ_da5SB-6WXtJ182xElOY6tr_cVV8xoGdtdpezleAOMcS3-BhdRdKYlbnouNAPafAjMKUE4Vj8v73wdn_Vljf4wgzb4nB_SUsGRCmH8-o3bVlrtI4wU2mDYTeJP7MCzlb20F-8vlCFiAKirLJQdITmxuInl_BdMdP2scUdO_j7WGPucr6JSqgUfVWTigSEPYCWAcpnRrJgJb0vh3uW-oVj7tHejw1WTOG7sCCxx_alSj4e1-hjPEI_gGOYO9Z4gGhvA79Fs", placeholder: "Note de personnalisation...", category: "vase" },
    { id: 4,  name: "Service Thé Minuit",price: 120, badge: "NOUVEAU",    img: "https://lh3.googleusercontent.com/aida/ADBb0uiycM4MnaTgZ-b8vXrDeuxMXQnvdAD9fRUlbNqcAto0U-DPu3FN98iTvgfb3WUebQG4ojqgILSIYSLFyn6YVQ8P7Q-D9SdVli85zADNsPUJdxQLhGZsg0MwZZav4YATA2VaHccEA4OpMCU72gEbL28wKXpyPHVctJfT2GdXzNeJVPWISF4U9WNW7xhIjaJtQ2xhVXcJujtteKa7_3o-9yqelmk_l_YnXxlK7hzfSFC7WfGWuF3DjRPfR2hbQhnbPmjstBK1d2H7Hw", placeholder: "Gravure souhaitée...", category: "service" },
    { id: 5,  name: "Tasse Terre Promise",price:28,  badge: "",           img: "https://lh3.googleusercontent.com/aida/ADBb0ugUgQeZeH3whOmOnkq3zBKNndkaE3vnaPSeFjYcDnJXSqri5zdftL22Wza0Nix27oUpatkAxeurqIOwE0ztYGGh40g5hHJANlb0AWK3txqkc3du-wO-PkRPrj4s6Z4hvUHp7qwzr4MUljP8df3g6b75YlguUIdWx03IsrR0bB6idSVVBgvhz83yccQyBc7DRgt541-s4B8SN1kMVQDx41ubq10FFY1cXn-7xt2wsTAZTG2_bSCtdl9Sy4tB59wGiN2gLygRmNDqX1E", placeholder: "Message...", category: "table" },
    { id: 6,  name: "Assiette Ondulation",price:42, badge: "",           img: "https://lh3.googleusercontent.com/aida/ADBb0uhX6VHg4vdZYMItymvI0z1tCFXaqL7gr1zTvPjJFnRd3o9KoOPZb5HbGYeGLPKIeednSSek4yXCkNsAq8b516EjO7nwGcYXWhNeJKjcJkHpakYqIa2XquBariRa6oNYDwRifJiNJoCeq3-DgPd-r6Vd-nzAknPPf0Fmg5Z6KUcvRk-UDbVAf3pLkAbHHLPFWML2IxL3QfIh5X0nHc4-OeuCHaS0bMZUeL2plhUzol3jdmvOvdwHwkgP9dT9meZ45dbQAWereghv_Wk", placeholder: "Personnalisation...", category: "service" },
    { id: 7,  name: "Bol Nuage",          price: 32, badge: "",           img: "https://lh3.googleusercontent.com/aida/ADBb0ugwOzhiTFGHC6bIGEIHd3iWCJXBfKClo4mq5GRkuH73LbjbSaS1uRblUWALHyhkhZInC9G1jhzMJbqVfXtRZ-jtLVtuz_sO8bTUOSDQI35xxUjKfJVUcCPZLaxBSlUMEjYi2BNZS1-rkdQEpIt1L7u4wy6P4NnKgnSTYY67Yto-R07pCgdbM3Uzpiq0kN16zW4fIBgcZmJyoNbrMIbQEJ54PVc_9MZuH23m6QBKXyc1EvtX1tyRq5Tzi_F4ZVBslI-fde3v_LBAv_Y", placeholder: "Message...", category: "table" },
    { id: 8,  name: "Plat Recto",         price: 68, badge: "",           img: "https://lh3.googleusercontent.com/aida/ADBb0uhArE_mXx8XUXUBxansXS9AOjwMQmt4ahrcapfbBCs15Sz7Z8LL3yJxZ8JjEcztd0UIJA5x7uRQ47EMnTjKLC1BQbl_RYpXRoqMzzjWH2kYpC3Bz5Uqoe72oUTqGTz7OFz-YU2GHqjaqAVC4BYSi96gIIYs-bqX5TKOnlD4itePpAI1OIQ_EWIKezZLZxZ_4dqjDKGDzQNboHUUX-l5WA6VtHBvxTqAenmFPWx7n33g5JhETTzFVUQNe_e9GiTcgxPG8h_REQKDTZ8", placeholder: "Gravure...", category: "service" },
    { id: 9,  name: "Porte-bijoux Lune",  price: 25, badge: "",           img: "https://lh3.googleusercontent.com/aida/ADBb0uh4Z58ZZZefJdKeVN04T4E_V9YOw1I5t8153aG-vlVyEMQ7QfoMNYYPx1mSdfrU4l2t0BLyBAttAxLGEP-bJjocGSd2I0vi1Lyg0nFJlQKxJK_mg2oJFnNlHJ-S553HHDBjnoUcntJatHpp-XpU42Cr8EeYTi3h4LrPnB0jivx7FCzsR1Rs57i_PTn2Y3djRLK9gD2Lr_U03nsT_3QQuHbDD7qStfJSbvVYJiI7o5SD0ukDxgwnLpGbQPCM5UCpDsIMcjwvNIZnwtM", placeholder: "", category: "deco" },
    { id: 10, name: "Pichet Argile",      price: 75, badge: "",           img: "https://lh3.googleusercontent.com/aida/ADBb0uiE9IIdMxxtpe55iR8rhO51-svHFL_I20IIZAiJsZFYsaGmb0fL71m2ZbasRlmDmg7GcdczFtTT42BjT2FdQ7pesW5fXmmTDY_RDvldU_7OGbgn9sTRWpjK8-kCuOWTslht63wtxIE5i4eEuMrPXlRXG40rFrzPGGBs5Z3m-XjbNhmV9Ql2p_eseookUcGGu7wdalxbkoGsmkrDb2kgCTuZAHuQsmm3Hly00tFb5VcbTDKsyVKkcvcv2KG0K6FX8SIBzLQchvB-88k", placeholder: "", category: "vase" },
    { id: 11, name: "Vase Ocre",          price: 110,badge: "",           img: "https://lh3.googleusercontent.com/aida/ADBb0ujrBI5dGBH1d5HJLkU5rGmVqoIkT9RM-HTq3XBB3hkxWEJSvlg5pGA6Pe0m_WQk7lGnLXUjDRCEsOFmQdVnhTs7vGZB7dPK9XC7-bhzfoXCf4VaF6rn4nYMvSsnNS0W6Bzx4TjMfIl5SKvIB_Kc3iEgMcr6rl2AUTSv8MxRAxqzd6lB_ejdL74nO7kZss0A_hFqPcADeawIhc-NCfJhX1pabTlqcCbYM57BRQxKVeyvez1Iutnq2mNovnVFiGxqSkO8TiDZtWswj_o", placeholder: "", category: "vase" },
    { id: 12, name: "Gobelet Sable",      price: 22, badge: "",           img: "https://lh3.googleusercontent.com/aida/ADBb0uiLLqXBtNHdE6RmDfgSBwilu3AZHVZT8sv_mi10jzLv6FNmLBD6G7YD_5JghsBsXvcFYgvJYk9CtZcM3Fcxp9cfc19DwN6YXkLIRsaD5LvYAZYrvsUiS3pirYa3mwsHLFcLZn-0TOjeAnTY5XOQaXzXPViuVI-4NUsRP7ldetWjKJVeXxcgj97Q2T7L_DBWMAhNLlExcgkAXCvlD572Rr3Dro9er4qz-ikIKuLzwxp9kgIyeMBEh10ZUlCpliC7YSsEy6C4b98ZbPA", placeholder: "", category: "table" },
    { id: 13, name: "Collection Aube",    price: 55, badge: "",           img: "https://lh3.googleusercontent.com/aida/ADBb0uiO7VzcCGKdkaM2ScRKkMMURdiqdLjoR5lpbYzHqtUMDGJtSdera3cEg8bX2dxGa6EKvGqknGSGY-2AVVyWVmHODzVN4i6coW2iXQG995GRGxC1aKe8dK4_tPwWvvh-wZWg-ScfRO39fPomf4uTr0OCzI5XSpqQtu8Da65Z806r-ejXoBAR8x78NsSX-K0O_8EeGv67ttJMMFdnCg5-5ZdHXw8hG6TwcqQybTWPqPv5kDudWCqdAkrQBW4lURCr9TMHdEytKJHOIp0", placeholder: "", category: "deco" },
    { id: 14, name: "Set Botanique",      price: 95, badge: "BEST SELLER",img: "https://lh3.googleusercontent.com/aida/ADBb0ugZQjbakYycg0yyWaioSDaiGrJlNJFs9Fuisr6orivw3rP1tzGwbYQa1h6VRgeUiqoD3xUyDs-4nbi6QjeUrsDQuFHuXbmt6hKBnOyCgWxQeI_jKGSbgrIZP4IKJAgm3DLKqX556BlvNJA6CerA49QjHMWyHY-LyU9fAKDXeM6tNyWvf07DhMQhoG-ITBRkGbIagGii68BtCZmbCGeDUDOTkVVBe_EVaR_CRP9xXbbRYtsfoeI2_bpG8XuYCtIPQ0dikhTCmfSlygI", placeholder: "", category: "deco" },
    { id: 15, name: "Vase Coquille",      price: 140,badge: "",           img: "https://lh3.googleusercontent.com/aida/ADBb0uiXDs7fnsxwUmdk4Mo6dZ_P3UUmP0foUT_Hyrb7h04jUpoLDBN02kd4wryrxA98McQC1Jp6ae5C3sf7ArakppsyNljEaS7erano838VbQt1Ez-YcSsV3ttjAxyALijFR-P6aJaB0zNTYzK80J68PAAgo4yo1gzTKph1IADmJji7F60qfsd7hXWnRiFNRmOIHlGmS8vH6V5rDU3oxRJNZ80xM0Ypw89K-ttZiDIJ03z_ZlEaCziobBbBHriNj8_0T0oEtscEG360zSA", placeholder: "", category: "vase" },
    { id: 16, name: "Coupelle Brume",     price: 38, badge: "",           img: "https://lh3.googleusercontent.com/aida/ADBb0ujXB0BqVpC0mUPNfeBd_mdmS7KtgiHEUpoL9wH7Zugn_nLPSp_vZEjH4S9y1FPrD4TTE-3X3nDQs2Xxr1f_khiH0MMtemNe0Ny-beHpqJUw109BBNDqq4oslr5UnYQUSXyJZUZ18gwCVVm6Em0MkTFSnYSc-mPfe8rnkXVqnk2MlLaaloDOlzssqkB47Y8WzFehp2tfL-7bmnV4uKrJ03G7admKNi_bq7c4fURWCoSEfc5i8gtoW6J2r6p9CB9eJFy-NJSvJYlA9Hk", placeholder: "", category: "deco" },
    { id: 17, name: "Soliflore Épure",    price: 49, badge: "",           img: "https://lh3.googleusercontent.com/aida/ADBb0uipR48tAzfOAjRgqhPNKZoJp-DjMilnBh9h1XGBJWIdMe5cwnFcy-mdtbG5z1dW4upumEse2WfglrVTDL5GwxPtFy-AWAXENABrHKkP6H0OYVyCFNt5DJmAC1f6pAAcYIJuFfhrylnKqi8Wdh5iBB3agEqcYnv7J2iqVS2Fzq79LRkYedWTXmaSz-yNmTylkN8uI7c1wm6TbBHbtTXbNiBuPX1ZCiww4gFxRhpan3tyjIW99Fc8rOOL2ux3OAhy8McgdUzsF3S79po", placeholder: "", category: "vase" },
    { id: 18, name: "Duo Amoureux",       price: 65, badge: "GIFT",       img: "https://lh3.googleusercontent.com/aida/ADBb0uga8pXcO_beNOYNpvb7sK4JCD_1egOGJZhXZ2llHvoxIL7Jp2Ea-Q8m1azz6dqrwz7xejB0RbTVh__UAjwgT6RX8D16SUCSLXQrIyWsdVyoOM2lTquDpm4wjAJBp-lKC5FGVtXMb1awfkybusMMNVgGzwjJOJdaeRoiAF7qbAUSgIYd_DdJ3ZZ5hYrc8rvgY0RhSrbjkf_iqGkZOwZ_dvGq8tII_UodSnMTZWBldqhQ6zWuF2nzg2sIiXBUOnqx_QS6q1WviiGoQLA", placeholder: "", category: "deco" },
    { id: 19, name: "Bol Zen",            price: 34, badge: "",           img: "https://lh3.googleusercontent.com/aida/ADBb0ugyOkHgW8WwDfskeum7ym2sVX5pZBMfqzjV3SsqwSs4ZVadMJrP811_4C2_0sOE6Toqgfuj35W0bRjl9AMXBouoFHiRYqbtt5uj0omNXBZvX36ZDNiKBrh9E3KPcyj1t5WWuusD94kCAebA95HNMzEn1Nhi-9lg_0zAlaTAvDyOWzOAxqU4delUD6K8NOL8i2MuQb0PME4NE-P2ZWm3t--C3T-2d6WJXNYKRXXmz5jto5Z-SQyCbmNjQd5hqUK3g_W9MdFo9CyxWko", placeholder: "", category: "table" },
    { id: 20, name: "Plat Sillage",       price: 155,badge: "",           img: "https://lh3.googleusercontent.com/aida/ADBb0uhijpWqQWeSTrc6dvCqo8W008CQsQzioi3B2RmMdsF-LbFafy3OL6oUiGmtS_KObRwOUy6vP7XpTxAnGi15Su6V0jFM5-UZ8fMloVkk3tyIzGmvi-s4ok86aUJyvhC845q3P8EOuM0_IE-8AnPpysW-CELh3W-qeenRPQkavcduuxQ58zsNoR1kMTp5lujWwCTtPGHQK4SyKwrzrAHp3rcVjU8KwQ_Oss1JO6dowRSz2CXUEQLwnlaNUZTg0BoKE1412GYNGyVxF-g", placeholder: "", category: "service" },
    { id: 21, name: "Verseuse Antique",   price: 115,badge: "",           img: "https://lh3.googleusercontent.com/aida/ADBb0ugjcD9dbEAZaPhm9bELAnLIFJlbrQg3607MQR2WBE9Z1k8RugHJvFKcCiwB9nPXbf_AZTGL3BWZdpIJcuTHMWaKTcUABkzoY0ZG3UIS6zFIWPuK3VpnddgpE-TapAtMW__vdhMVcJz_y9dxwaplNCAAyuMZAgnNKmBnTIOFfGKI8HwiIpWkXdU2zMMYtK29vpRUhYeGYJO6tQG7cCQURnz5m8I6iIfcbBm0Fj80u7Psn05sJWUnnuuwDXjhH-1Q4QAHxBXV0YJZDNc", placeholder: "", category: "vase" },
    { id: 22, name: "Cache-pot Lin",      price: 88, badge: "",           img: "https://lh3.googleusercontent.com/aida/ADBb0ugwUlTK26tJ-GdoudRZB0_zzX9-O2A0XeXcrjwCkjo15bieuBVRMK1mf_H57j0ezJKX_-9jCqqrew8f45e7dfPlusr58AvoP_CwsJxetTta5tJqWp_w1GjdepHtzGC8gafzvVrqlfJVP9lpfdxeaT31-HvC2gjVp8WQD4aAWYItmsClAYQ5x5FKCbh5jA2f8eZogpwlkvpNL6V-IDPkd2yJ-NdJU7PxJcxlSE8RFi7smNq0yNzVZbiNHRKEEMZsZGF_7sh3JLODmuA", placeholder: "", category: "deco" },
  ];

  // ── Site Settings (admin-editable) ───────────────────────────────────────
  const DEFAULT_SETTINGS = {
    // Nav
    brandName: 'TraceDuTemps',
    nav1label: 'Collections', nav2label: 'Our Story', nav3label: 'Gifts', nav4label: 'Bespoke',
    // Banner
    announcementBar: 'Livraison gratuite sur Tunis · Pièces faites à la main · Certifiées artisan',
    bannerBg: '#884b3a', bannerColor: '#ffffff', bannerVisible: true,
    // Hero
    heroTitle: "Certains instants méritent l'éternité",
    heroSubtitle: "Chaque pièce est façonnée à la main dans notre atelier à Tunis. Un objet de céramique qui capture un moment.",
    heroLabel: 'Artisanat céramique · Tunis',
    heroCta1: 'Explorer la Collection', heroCta2: "Découvrir Notre Histoire",
    heroBg: 'https://lh3.googleusercontent.com/aida/ADBb0ujrBI5dGBH1d5HJLkU5rGmVqoIkT9RM-HTq3XBB3hkxWEJSvlg5pGA6Pe0m_WQk7lGnLXUjDRCEsOFmQdVnhTs7vGZB7dPK9XC7-bhzfoXCf4VaF6rn4nYMvSsnNS0W6Bzx4TjMfIl5SKvIB_Kc3iEgMcr6rl2AUTSv8MxRAxqzd6lB_ejdL74nO7kZss0A_hFqPcADeawIhc-NCfJhX1pabTlqcCbYM57BRQxKVeyvez1Iutnq2mNovnVFiGxqSkO8TiDZtWswj_o',
    // Story
    storyLabel: "L'Âme de la Terre",
    storyTitle: "Inspirés de Sejnane & de la finesse de Carthage",
    storyP1: "TraceDuTemps est né du désir de capturer l'éphémère dans la permanence de l'argile. Nos artisans façonnent chaque pièce à la main, transformant la terre tunisienne en héritage.",
    storyQuote: '"Plus qu\'un objet, nous créons des ponts entre les générations."',
    storyCta: 'Commencer un projet sur mesure →',
    // Bespoke section
    bsLabel: 'Sur Mesure', bsTitle: "Empreintes d'Innocence",
    bsDesc: "Immortalisez la douceur des premiers jours. Nos commissions spéciales permettent de graver l'empreinte de la main de votre nouveau-né dans une plaque de céramique fine.",
    bsCheck1: 'Argile naturelle hypoallergénique',
    bsCheck2: 'Finition mate ou satinée au choix',
    bsCheck3: 'Gravure du prénom et de la date',
    bespokePrice: 450, bsBtn: 'Créer votre pièce unique →',
    // Catalogue
    colLabel: 'Catalogue 2024', colTitle: "Nos Chefs-d'œuvre",
    colSubtitle: "Une sélection intemporelle de pièces de céramique façonnées à la main, où chaque empreinte raconte une histoire de patience et de poésie.",
    hpProductsTitle: "Nos Chefs-d'œuvre",
    hpProductsSub: "Sélection curatée de pièces de céramique d'exception",
    // Quotes
    quote1: '"La main de l\'artisan ne fait pas que façonner la matière, elle y dépose une promesse de mémoire."',
    quote2: "La terre ne ment jamais; elle garde l'empreinte de celui qui l'a aimée.",
    quote2attr: "L'Esprit TraceDuTemps",
    quote3: '"Les mains d\'un enfant sont les premières empreintes de l\'âme sur le monde. Nous les rendons éternelles."',
    // Footer
    footerTagline: "Artisanat céramique artisanale dédié à la création d'objets porteurs d'âme.",
    footerCopyright: '© 2024 TraceDuTemps. Some Moments Deserve Forever.',
    footerAddress: 'Atelier à Tunis, Borj Amri',
    instagramUrl: '#', facebookUrl: '#',
    contactEmail: 'contact@tracedutemps.tn', contactPhone: '+216 XX XXX XXX',
    footerCol1Title: 'Exploration', footerCol2Title: 'Légal', footerCol3Title: 'Contact',
    footerNewsletterTitle: 'Newsletter',
    footerNewsletterText: 'Rejoignez notre cercle pour des invitations exclusives.',
    cartDeliveryNote: 'Livraison assurée dans 48h sur Grand Tunis',
    // Shipping
    shippingFee: 8, shippingFreeAbove: 300,
    giftWrapFee: 15,
    giftWrapDesc: "Chaque pièce est emballée à la main dans du papier texturé recyclé avec un sceau de cire.",
    shippingDelay: '48 heures sur Grand Tunis',
    trust1Title: 'Insured Courier Delivery', trust1Desc: 'Hand-delivered within 48 hours across Tunisia.',
    trust2Title: 'Artisan Authenticity', trust2Desc: 'Every order includes a signed certificate of origin.',
    // Design
    colorPrimary: '#884b3a', colorSurface: '#fff8f5', colorSurfaceLow: '#fff1e9',
    colorOnSurface: '#28180b', colorVariant: '#53433f', colorOutline: '#85736e',
    fontTitle: 'Noto Serif', fontBody: 'Inter',
    // SEO
    seoTitle: "TraceDuTemps | Certains instants méritent l'éternité",
    seoDesc: "Céramiques artisanales faites à la main à Tunis.",
    seoKeywords: 'céramique, artisanat, Tunis, fait main, bespoke',
    tiktokUrl: '', publicEmail: 'contact@tracedutemps.tn', publicPhone: '+216 XX XXX XXX',
    maintenance: false, maintenanceMsg: 'Notre boutique sera de retour très bientôt…',
  };

  // ── Cart ─────────────────────────────────────────────────────────────────
  function getCart() {
    try { return JSON.parse(localStorage.getItem('tdt_cart') || '[]'); }
    catch { return []; }
  }
  function saveCart(cart) {
    localStorage.setItem('tdt_cart', JSON.stringify(cart));
    window.dispatchEvent(new CustomEvent('tdt:cartUpdated'));
  }
  function addToCart(productId, qty = 1, message = '') {
    const products = getProducts();
    const product = products.find(p => p.id === productId);
    if (!product) return;
    const cart = getCart();
    const existing = cart.find(i => i.id === productId && i.message === message);
    if (existing) existing.qty += qty;
    else cart.push({ id: productId, name: product.name, price: product.price, img: product.img, qty, message });
    saveCart(cart);
    showCartToast(product.name);
  }
  function removeFromCart(productId, message = '') {
    const cart = getCart().filter(i => !(i.id === productId && i.message === message));
    saveCart(cart);
  }
  function updateQty(productId, message, delta) {
    const cart = getCart();
    const item = cart.find(i => i.id === productId && i.message === message);
    if (item) {
      item.qty += delta;
      if (item.qty <= 0) return removeFromCart(productId, message);
    }
    saveCart(cart);
  }
  function getCartTotal() {
    return getCart().reduce((sum, i) => sum + i.price * i.qty, 0);
  }
  function getCartCount() {
    return getCart().reduce((sum, i) => sum + i.qty, 0);
  }
  function clearCart() { saveCart([]); }

  // ── Products ─────────────────────────────────────────────────────────────
  function getProducts() {
    try {
      const stored = localStorage.getItem('tdt_products');
      return stored ? JSON.parse(stored) : DEFAULT_PRODUCTS;
    } catch { return DEFAULT_PRODUCTS; }
  }
  function saveProducts(products) {
    localStorage.setItem('tdt_products', JSON.stringify(products));
  }

  // ── Settings ─────────────────────────────────────────────────────────────
  function getSettings() {
    try {
      const stored = localStorage.getItem('tdt_settings');
      return stored ? { ...DEFAULT_SETTINGS, ...JSON.parse(stored) } : DEFAULT_SETTINGS;
    } catch { return DEFAULT_SETTINGS; }
  }
  function saveSettings(settings) {
    localStorage.setItem('tdt_settings', JSON.stringify(settings));
  }

  // ── Orders ───────────────────────────────────────────────────────────────
  function getOrders() {
    try { return JSON.parse(localStorage.getItem('tdt_orders') || '[]'); }
    catch { return []; }
  }
  function addOrder(order) {
    const orders = getOrders();
    order.id = 'TDT-' + Date.now();
    order.date = new Date().toISOString();
    order.status = 'En attente';
    orders.unshift(order);
    localStorage.setItem('tdt_orders', JSON.stringify(orders));
    return order.id;
  }
  function updateOrderStatus(orderId, status) {
    const orders = getOrders();
    const o = orders.find(x => x.id === orderId);
    if (o) o.status = status;
    localStorage.setItem('tdt_orders', JSON.stringify(orders));
  }

  // ── Toast notification ───────────────────────────────────────────────────
  function showCartToast(name) {
    const toast = document.createElement('div');
    toast.className = 'tdt-toast';
    toast.innerHTML = `<span style="font-size:18px">✓</span> <strong>${name}</strong> ajouté au panier`;
    document.body.appendChild(toast);
    requestAnimationFrame(() => toast.classList.add('tdt-toast--visible'));
    setTimeout(() => {
      toast.classList.remove('tdt-toast--visible');
      setTimeout(() => toast.remove(), 400);
    }, 2500);
  }

  // ── Shared CSS injected once ─────────────────────────────────────────────
  function injectBaseStyles() {
    if (document.getElementById('tdt-base-styles')) return;
    const style = document.createElement('style');
    style.id = 'tdt-base-styles';
    style.textContent = `
      .tdt-toast {
        position: fixed; bottom: 32px; right: 32px; z-index: 9999;
        background: #28180b; color: #fff8f5;
        padding: 14px 24px; border-radius: 4px;
        font-family: Inter, sans-serif; font-size: 14px;
        display: flex; align-items: center; gap: 10px;
        transform: translateY(20px); opacity: 0;
        transition: all 0.35s cubic-bezier(0.16,1,0.3,1);
        pointer-events: none; box-shadow: 0 8px 32px rgba(40,24,11,.25);
      }
      .tdt-toast--visible { transform: translateY(0); opacity: 1; }
    `;
    document.head.appendChild(style);
  }

  // ── Nav badge updater ─────────────────────────────────────────────────────
  function initCartBadge() {
    injectBaseStyles();
    function update() {
      const badges = document.querySelectorAll('[data-cart-badge]');
      const count = getCartCount();
      badges.forEach(b => {
        b.textContent = count;
        b.style.display = count > 0 ? 'flex' : 'none';
      });
    }
    update();
    window.addEventListener('tdt:cartUpdated', update);
  }

  return {
    getCart, saveCart, addToCart, removeFromCart, updateQty,
    getCartTotal, getCartCount, clearCart,
    getProducts, saveProducts,
    getSettings, saveSettings,
    getOrders, addOrder, updateOrderStatus,
    showCartToast, initCartBadge,
  };
})();
